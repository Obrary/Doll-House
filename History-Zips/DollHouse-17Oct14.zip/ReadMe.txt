Product: Doll House, October 2014

Designer: Ingrid Gjermstad

Support:  http://forums.obrary.com/category/designs/doll-house

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
The dollhouse measures 47 cm tall, 42 cm deep and 49 cm wide.  It can be made from wood or MDF. It can be the home of dolls with a height of about 8-10 cm. 